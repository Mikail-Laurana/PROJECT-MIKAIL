<?php
    session_start();
    include "../config/koneksi.php";

    $user = $_POST['username'];
    $pass = $_POST['password'];

    $data = mysqli_query($conn,"SELECT * FROM users WHERE username='$user' AND password='$pass'");
    $cek = mysqli_fetch_assoc($data);

    if($cek){
        $_SESSION['id'] = $cek['id'];
        $_SESSION['nama'] = $cek['nama'];
        $_SESSION['role'] = $cek['role'];

        if($_SESSION['role'] == 'admin'){
            header("Location:../admin/dashboard.php");
        }else{
            header("Location:../user/dashboard.php");
        }
    }else{
        echo"Username/Password SALAH!";
    } 
?>