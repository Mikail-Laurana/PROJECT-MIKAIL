<?php
    include "../config/koneksi.php";
    
    session_start();

    $nama = $_POST['nama'];
    $user = $_POST['username'];
    $pass = $_POST['password'];

    if(isset($_POST['daftar'])){
        mysqli_query($conn,"INSERT INTO users (nama,username,password,role) VALUES ('$nama','$user','$pass','user')");
        header("Location:../index.php");
    }else{
        echo"Gagal Mendaftar";
    }
?>            