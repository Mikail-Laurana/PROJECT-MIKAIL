<?php
    $conn=mysqli_connect("localhost","root","","perspusmiko");
    if(!$conn){
        die('koneksi gagal');
    }
?>