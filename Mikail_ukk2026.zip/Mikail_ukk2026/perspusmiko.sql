-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 12, 2026 at 09:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perspusmiko`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id_buku` int(11) NOT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `pengarang` varchar(100) DEFAULT NULL,
  `stok` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id_buku`, `judul`, `pengarang`, `stok`) VALUES
(2, 'Machine Learning', 'Yanto', 296),
(4, 'Matematika', 'Balqis', 991),
(5, 'UTBK WANGSIT', 'Yanto', 985),
(6, 'Hujan 2', 'Tere Liye', 245);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_buku` int(11) DEFAULT NULL,
  `tanggal_pinjam` date DEFAULT NULL,
  `tanggal_kembali` date DEFAULT NULL,
  `status` enum('dipinjam','kembali') DEFAULT 'dipinjam'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_user`, `id_buku`, `tanggal_pinjam`, `tanggal_kembali`, `status`) VALUES
(56, 10, 5, '2026-02-12', '2026-02-12', 'kembali'),
(57, 10, 5, '2026-02-12', '2026-02-12', 'kembali'),
(58, 10, 5, '2026-02-12', '2026-02-12', 'kembali'),
(59, 10, 5, '2026-02-12', '2026-02-12', 'kembali'),
(60, 10, 5, '2026-02-12', '2026-02-12', 'kembali'),
(61, 10, 4, '2026-02-12', '2026-02-12', 'kembali'),
(62, 10, 4, '2026-02-12', '2026-02-12', 'kembali'),
(63, 10, 4, '2026-02-12', '2026-02-12', 'kembali'),
(64, 10, 2, '2026-02-12', '2026-02-12', 'kembali'),
(65, 10, 2, '2026-02-12', '2026-02-12', 'kembali'),
(66, 10, 2, '2026-02-12', '2026-02-12', 'kembali'),
(67, 10, 2, '2026-02-12', '2026-02-12', 'kembali'),
(68, 10, 2, '2026-02-12', '2026-02-12', 'kembali'),
(69, 10, 2, '2026-02-12', '2026-02-12', 'kembali'),
(70, 10, 5, '2026-02-12', NULL, 'dipinjam'),
(71, 10, 5, '2026-02-12', NULL, 'dipinjam'),
(72, 10, 6, '2026-02-12', '2026-02-12', 'kembali'),
(73, 10, 6, '2026-02-12', NULL, 'dipinjam'),
(74, 10, 6, '2026-02-12', NULL, 'dipinjam'),
(75, 10, 6, '2026-02-12', NULL, 'dipinjam'),
(76, 10, 6, '2026-02-12', NULL, 'dipinjam'),
(77, 10, 6, '2026-02-12', NULL, 'dipinjam'),
(78, 10, 6, '2026-02-12', NULL, 'dipinjam'),
(79, 10, 5, '2026-02-12', NULL, 'dipinjam'),
(80, 10, 5, '2026-02-12', NULL, 'dipinjam'),
(81, 10, 5, '2026-02-12', NULL, 'dipinjam'),
(82, 10, 5, '2026-02-12', NULL, 'dipinjam'),
(83, 10, 5, '2026-02-12', NULL, 'dipinjam'),
(84, 10, 5, '2026-02-12', NULL, 'dipinjam'),
(85, 10, 5, '2026-02-12', NULL, 'dipinjam'),
(86, 10, 5, '2026-02-12', NULL, 'dipinjam'),
(87, 10, 5, '2026-02-12', NULL, 'dipinjam'),
(88, 10, 4, '2026-02-12', '2026-02-12', 'kembali'),
(89, 10, 4, '2026-02-12', '2026-02-12', 'kembali'),
(90, 10, 2, '2026-02-12', NULL, 'dipinjam'),
(91, 10, 2, '2026-02-12', NULL, 'dipinjam'),
(92, 10, 2, '2026-02-12', NULL, 'dipinjam'),
(93, 10, 2, '2026-02-12', NULL, 'dipinjam'),
(94, 10, 5, '2026-02-12', NULL, 'dipinjam'),
(95, 10, 5, '2026-02-12', NULL, 'dipinjam'),
(96, 10, 5, '2026-02-12', NULL, 'dipinjam'),
(97, 10, 5, '2026-02-12', NULL, 'dipinjam'),
(98, 10, 6, '2026-02-12', NULL, 'dipinjam'),
(99, 10, 6, '2026-02-12', NULL, 'dipinjam'),
(100, 10, 6, '2026-02-12', NULL, 'dipinjam'),
(101, 10, 6, '2026-02-12', NULL, 'dipinjam');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('admin','user') DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nama`, `username`, `password`, `role`) VALUES
(6, 'admin', 'admin', 'admin123', 'admin'),
(10, 'MIKAIL LAURANA', 'miko123', '1234', 'user'),
(11, 'BALQIS ASIGA', 'balqis', '1234', 'user'),
(12, 'admin', 'admin', 'admin123', 'user'),
(13, 'admin', 'admin123', 'admin123', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id_buku`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_buku` (`id_buku`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `id_buku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id_buku`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
