<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
</head>
<body>

    <div class="container">
        <form action="auth/proses_login.php" method="post">
            <h2 class="TEXT">Halaman Login</h2>
            <label >Username </label><br> 
            <input type="text" name="username" required style="width: 100%;"><br> 
            <label >Password</label> <br>
            <input type="password" name="password" required style="width: 100%;"><br>
            <button type="submit" name="login" class="Button">LOGIN</button> 
            <p>Belum Punya Akun? <a href="auth/register.php">Register</a></p>
        </form>
    </div>
</body>
</html>

<style>
    body{
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        overflow: hidden;
    }

    .Button{
        display: flex;
        align-items: center;
        justify-content: center;
        justify-content: center;
        margin-top: 5px;
    }

    input{
        margin-bottom: 2px;
    } 
        
    h2{
        display: flex;
        justify-content: center;
        align-items: center;
    }

    button{
        padding: 8px 15px;
        background: green;
        border: none;
        color: white;
        border-radius: 5px;
        cursor: pointer;
        transition: 0.3s;
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 10px;
        margin-left: 60px;
    }

    button:hover{
        background: greenyellow;
    }

    label{
        align-items: center;
        justify-content: center;
        margin-left: 60px;
    }

</style>

