<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="navbar">
            <h2>Selamat Datang <?= $_SESSION['nama'] ?></h2>
            <a href="lihat_buku.php">Lihat Buku Yang Tersedia</a> 
            <a href="riwayat.php">Lihat Riwayat Peminjaman</a> 
            <a href="../auth/logout.php">Logout</a> 
        </div>
    </div>
</body>
</html>

<style>
    .navbar{
        margin-bottom: 20px;
    }

    .navbar a{
        text-decoration: none;
        padding: 8px 14px;
        background: #3498db;
        color: white;
        border-radius: 5px;
        margin-right: 5px;
        transition: 0.3s;
        font-size: 14px;
    } 

    .navbar a:hover{
        background: #2980b9;
    }

    .container{
        width: 100%;
        max-width: 1100px;
        margin: auto;
        background: white;
        padding: 25px;
        border-radius: 20px;
        box-shadow: 0,4px,10px rgba(0, 0, 0, 0.08);
        display: flex;
        justify-content: center;
        align-items: center;
        overflow: hidden;
    }

    h2{
        text-align: center;
    }
</style>