<?php
    include "../config/koneksi.php";
    session_start();
    $id = $_SESSION['id'];
    $no = 1;

    $cari = $_GET['cari'] ?? '' ;
?>

<h2>Riwayat Peminjaman</h2>

<form method="get">
    <input type="text" name = "cari" placeholder="Cari Nama/Buku" value ="<?= $cari ?>">
    <button type="submit" name="KonfirmCari">Cari</button>
</form>

<table border="1">
    <tr>
        <th>No</th>
        <th>Judul</th>
        <th>Tanggal Pinjam</th>
        <th>Tanggal Kembali</th>
        <th>Status</th>
        <th>Aksi</th>
    </tr>

    <?php
        $data = mysqli_query($conn,"SELECT t.*,b.judul FROM transaksi t JOIN buku b ON b.id_buku = t.id_buku WHERE id_user = '$id' AND judul LIKE '%$cari%'");
        while($d = mysqli_fetch_assoc($data)) { 
    ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $d['judul'] ?></td>
            <td><?= $d['tanggal_pinjam'] ?></td>
            <td><?= $d['tanggal_kembali'] ?></td>
            <td>
                <?php if($d['status'] == 'dipinjam') { ?>
                    <label class="dipinjam">Dipinjam</label>
                <?php } else { ?>
                    <label class="kembali">Kembali</label>
                <?php } ?>
            </td>
            <td>
                <?php if($d['status'] == 'dipinjam') { ?>
                    <a href="kembali_buku.php?id=<?= $d['id_transaksi']?>">Kembalikan Buku</a>
                <?php } else { ?>
                    <p>Sudah</p>
                <?php } ?>
            </td>
        </tr>
    <?php } ?>
</table>
<br>
<button class="button"><a href="dashboard.php">Kembali</a></button> 
<style>
    .kembali{
        color: #33b377;
    }

    .dipinjam{
        color: #a81322;
    }

    table{
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
    }

    table th{
        background: #34495e;
        color: white;
        padding: 10px;
        text-align: left;
    }

    table td {
        padding: 8px;
        border-bottom: 1px solid #ddd;
    }

    table tr:hover{
        background: #f1f1f1;
    }

    

    button{
        padding: 8px 15px;
        background: green;
        border: none;
        color: white;
        border-radius: 5px;
        cursor: pointer;
        transition: 0.3s;
    }

    button:hover{
        background: greenyellow;
    }

    form{
        margin-bottom: 20px;
    }

    input,select{
        padding: 8px;
        margin: 5px 0;
        width: 100%;
        border: 1px solid #ddd;
        border-radius: 5px;
    }

    h2{
        text-align: center;
    }
    
    .button{
        padding: 8px 15px;
        background: #caab0e;
        border: none;
        color: white;
        border-radius: 5px;
        cursor: pointer;
        transition: 0.3s;
    }
</style>