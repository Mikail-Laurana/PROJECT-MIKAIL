<?php
    session_start();
    include "../config/koneksi.php";

    $id_user = $_SESSION['id'];
    $id_buku = $_GET['id'];

    mysqli_query($conn,"INSERT INTO transaksi (id_user,id_buku,tanggal_pinjam,status) VALUES ('$id_user','$id_buku',CURDATE(),'dipinjam')");
    mysqli_query($conn,"UPDATE buku SET stok = stok - 1 WHERE id_buku = '$id_buku'");
    header("Location:lihat_buku.php");
?>