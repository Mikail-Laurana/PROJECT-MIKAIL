<?php
    include "../../config/koneksi.php";
    
    $id_user = $_GET['id'];
    mysqli_query($conn,"DELETE FROM users WHERE id = '$id_user'");
    header("Location:lihat_anggota.php");
?>