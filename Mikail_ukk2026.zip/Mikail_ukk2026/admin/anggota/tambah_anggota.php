<?php
    session_start();
    if($_SESSION['role'] != 'admin'){
        header("Location:../../index.php");
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="proses_nambah.php" method="post">
        <h2>Tambah Akun</h2>
        Nama <br><input type="text" name="nama" required><br> 
        Username <br><input type="text" name="username" required><br> 
        Password <br><input type="password" name="password" required><br>
        <button type="submit" name="daftar">Daftar</button> 
    </form>
</body>
</html>

<style>
    body{
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        overflow: hidden;
    }

    .Button{
        display: flex;
        align-items: center;
        justify-content: center;
        justify-content: center;
        margin-top: 5px;
    }

    input{
        margin-bottom: 2px;
    } 
        
    h2{
        display: flex;
        justify-content: center;
        align-items: center;
    }

    button{
        padding: 8px 15px;
        background: green;
        border: none;
        color: white;
        border-radius: 5px;
        cursor: pointer;
        transition: 0.3s;
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 10px;
        margin-left: 50px;
    }

    button:hover{
        background: greenyellow;
    }

    .container{
        border: black;
    }


</style>

