<?php
    include "../../config/koneksi.php";

    $id = $_GET['id'];
    $d = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM users WHERE id = '$id'"));
    session_start();
    if($_SESSION['role'] != 'admin'){
        header("Location:../../index.php");
    }
?>



<div class="center_items">
    <form method="POST">
        <h2>Edit Anggota</h2>
        <input type="hidden" name="id" value="<?= $d['id'] ?>">
        <label>Nama</label><br><input name="nama" required value="<?= $d['nama'] ?>"><br>
        <label>Username</label><br><input name="username" required value="<?= $d['username'] ?>"><br>
        <label>Password</label><br><input name="password" required value="<?= $d['password'] ?>"><br>
        <button name="edit" type="submit">Edit</button>
    </form>
</div>

<?php 
    if(isset($_POST['edit'])){
        $id= $_POST['id'];
        $nama= $_POST['nama'];
        $user= $_POST['username'];
        $pass = $_POST['password'];

        $update = mysqli_query($conn,"UPDATE users SET nama='$nama',username='$user',password='$pass' WHERE id = '$id'");
        if($update){
            header("Location:lihat_anggota.php");
        }else{
            echo"Gagal Mengedit";
        }
    }
?>


<style>
    .center_items{
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        overflow: hidden;
    }

    .Button{
        display: flex;
        align-items: center;
        justify-content: center;
        justify-content: center;
        margin-top: 5px;
    }

    input{
        margin-bottom: 2px;
    } 
        
    .TEXT{
        display: flex;
        justify-content: center;
        align-items: center;
    }

    button{
        padding: 8px 15px;
        background: green;
        border: none;
        color: white;
        border-radius: 5px;
        cursor: pointer;
        transition: 0.3s;
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 10px;
        margin-left: 50px;
    }

    button:hover{
        background: greenyellow;
    }

    .container{
        border: black;
    }

    h2{
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>
