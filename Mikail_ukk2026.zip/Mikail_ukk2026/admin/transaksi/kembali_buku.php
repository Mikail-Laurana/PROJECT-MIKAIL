<?php
    include "../../config/koneksi.php";

    $id_transaksi = $_GET['id'];

    mysqli_query($conn,"UPDATE transaksi SET tanggal_kembali= CURDATE(),status='kembali' WHERE id_transaksi ='$id_transaksi'");
    $d = mysqli_fetch_array(mysqli_query($conn,"SELECT id_buku FROM transaksi WHERE id_transaksi = '$id_transaksi'"));
    $id_buku = $d['id_buku'];
    mysqli_query($conn,"UPDATE buku SET stok = stok+1 WHERE id_buku = '$id_buku' ");

    header("Location: lihat_transaksi.php");
?>