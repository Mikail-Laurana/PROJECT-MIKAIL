<?php
    include "../../config/koneksi.php";
    session_start();
    if($_SESSION['role'] != 'admin'){
        header("Location:../../index.php");
    }
?>

<div class="center_items">
    <form method="POST">
        <h2>Tambah Buku</h2>
        Judul <br><input name="judul" required><br>
        Pengarang <br><input name="pengarang" required><br>
        Stok <br><input name="stok" required><br>
        <button name="tambah" type="submit">Tambah</button>
    </form>
</div>


<?php

    if(isset($_POST['tambah'])){
        $judul = $_POST['judul'];
        $pengarang = $_POST['pengarang'];
        $stok = $_POST['stok'];

        mysqli_query($conn,"INSERT INTO buku (judul,pengarang,stok) VALUES ('$judul','$pengarang','$stok')");
        header("Location:lihat_buku.php");
    }
?>

<style>
    .center_items{
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        overflow: hidden;
    }

    .Button{
        display: flex;
        align-items: center;
        justify-content: center;
        justify-content: center;
        margin-top: 5px;
    }

    input{
        margin-bottom: 2px;
    } 
        

    button{
        padding: 8px 15px;
        background: green;
        border: none;
        color: white;
        border-radius: 5px;
        cursor: pointer;
        transition: 0.3s;
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 10px;
        margin-left: 50px;
    }

    button:hover{
        background: greenyellow;
    }

    .container{
        border: black;
    }

    h2{
        display: flex;
        justify-content: center;
        align-items: center;
    }

    
</style>
