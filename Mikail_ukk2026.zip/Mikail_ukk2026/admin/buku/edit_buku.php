<?php
    include "../../config/koneksi.php";

    $id = $_GET['id'];
    $d = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM buku WHERE id_buku = '$id'"));
    session_start();
    if($_SESSION['role'] != 'admin'){
        header("Location:../../index.php");
    }
?>



<div class="center_items">
    <form method="POST">
        <h2>Edit Buku</h2>
        <input type="hidden" name="id_buku" value="<?= $d['id_buku'] ?>">
        <label>Judul</label><br><input name="judul" required value="<?= $d['judul'] ?>"><br>
        <label>Pengarang</label><br><input name="pengarang" required value="<?= $d['pengarang'] ?>"><br>
        <label>Stok</label><br><input name="stok" required value="<?= $d['stok'] ?>"><br>
        <button name="edit" type="submit">edit</button>
    </form>
</div>

<?php 
    if(isset($_POST['edit'])){
        $id= $_POST['id_buku'];
        $judul= $_POST['judul'];
        $pengarang= $_POST['pengarang'];
        $stok= $_POST['stok'];

        $update = mysqli_query($conn,"UPDATE buku SET judul='$judul',pengarang='$pengarang',stok='$stok' WHERE id_buku = '$_POST[id_buku]'");
        if($update){
            header("Location:lihat_buku.php");
        }else{
            echo"Gagal Mengedit";
        }
    }
?>


<style>
    .center_items{
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        overflow: hidden;
    }

    .Button{
        display: flex;
        align-items: center;
        justify-content: center;
        justify-content: center;
        margin-top: 5px;
    }

    input{
        margin-bottom: 2px;
    } 
        
    .TEXT{
        display: flex;
        justify-content: center;
        align-items: center;
    }

    button{
        padding: 8px 15px;
        background: green;
        border: none;
        color: white;
        border-radius: 5px;
        cursor: pointer;
        transition: 0.3s;
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 10px;
        margin-left: 50px;
    }

    button:hover{
        background: greenyellow;
    }

    .container{
        border: black;
    }

    h2{
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>
