<?php
    include "../../config/koneksi.php";
    
    $id_buku = $_GET['id'];
    mysqli_query($conn,"DELETE FROM buku WHERE id_buku = '$id_buku'");
    header("Location:lihat_buku.php");
?>