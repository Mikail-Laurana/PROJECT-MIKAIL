<?php
    include "../../config/koneksi.php";
    session_start();
    if($_SESSION['role'] != 'admin'){
        header("Location:../../index.php");
    }

    $no = 1;
    $cari = $_GET['cari'] ?? '' ;
?>



<form method="get">
    <input type="text" name = "cari" placeholder="Cari Judul Buku" value ="<?= $cari ?>">
    <button type="submit" name="KonfirmCari">Cari</button>
</form>

<br>



<table border="1">
    <tr>
        <th>No</th>
        <th>Judul</th>
        <th>Pengarang</th>
        <th>Stok</th>
        <th>Aksi</th>
    </tr>

    <?php
        $data = mysqli_query($conn,"SELECT * FROM buku WHERE judul LIKE '%$cari%'");
        while($d = mysqli_fetch_assoc($data)) { 
    ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $d['judul'] ?></td>
            <td><?= $d['pengarang'] ?></td>
            <td><?= $d['stok'] ?></td>
            <td>
                <a href="edit_buku.php?id=<?= $d['id_buku']?>">Edit Buku</a> |
                <a href="hapus_buku.php?id=<?= $d['id_buku']?>">Hapus Buku</a>
            </td>
        </tr>
    <?php } ?>
</table>

<br>
<button class="button"><a href="../dashboard.php">Kembali</a></button> <button class="button"><a href="tambah_buku.php">Tambah Buku</a></button>

<style>
    .kembali{
        color: #33b377;
    }

    .dipinjam{
        color: #a81322;
    }

    table{
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
    }

    table th{
        background: #34495e;
        color: white;
        padding: 10px;
        text-align: left;
    }

    table td {
        padding: 8px;
        border-bottom: 1px solid #ddd;
    }

    table tr:hover{
        background: #f1f1f1;
    }

    button{
        padding: 8px 15px;
        background: green;
        border: none;
        color: white;
        border-radius: 5px;
        cursor: pointer;
        transition: 0.3s;
    }

    button:hover{
        background: greenyellow;
    }

    form{
        margin-bottom: 20px;
    }

    input,select{
        padding: 8px;
        margin: 5px 0;
        width: 100%;
        border: 1px solid #ddd;
        border-radius: 5px;
    }

    h2{
        text-align: center;
    }

    a{
        color: #0d6efd;
    }

    a:hover{
        color: #0dcaf0;
        text-decoration: underline;
    }

    .button{
        padding: 8px 15px;
        background: #caab0e;
        border: none;
        color: white;
        border-radius: 5px;
        cursor: pointer;
        transition: 0.3s;
    }
</style>